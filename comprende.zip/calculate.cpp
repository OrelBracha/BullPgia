#include "calculate.hpp"
#include <string>
#include <stdexcept>
using std::string, std::to_string;

namespace bullpgia {
	const string calculateBullAndPgia(const string choosen, const string guess){
		if(choosen.length() != guess.length()){
			if(choosen.compare("")==0||guess.compare("")==0)
				throw std::invalid_argument("Error: empty!");
        return "0,0";
	}

    else{
        uint bull = 0;
        uint pgia = 0;
 		char bulled;
 		bool count[guess.length()];
        for(int i = 0; i<choosen.length(); i++){
        	check(choosen[i]);
        	bool flag=false;
				if(choosen[i]==guess[i]){
					bull++;
					flag=true;
					bulled=choosen[i];
				}

				if(!flag){
                for(int j = 0; j<guess.length(); j++){
                	check(guess[i]);
                	if(i!=j){
                    if(choosen[i]==guess[j]&&choosen[i]!=bulled){
                    	if(count[j]==false){
                            pgia++;
                            count[j]=true;
                            break;
                        }
                            }
                    			}
                	}
                }
            }
        	std::string s=(to_string(bull)+","+to_string(pgia));
         return s;
    }
	}
		void check(char c){
			if(c<48||c>57)
				throw std::invalid_argument("Error: not a number!");
		}
	}