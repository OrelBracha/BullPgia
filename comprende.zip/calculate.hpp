#pragma once

#include <string>

namespace bullpgia {

	const std::string calculateBullAndPgia(const std::string chosen, const std::string guess);
	void check(char);
}
